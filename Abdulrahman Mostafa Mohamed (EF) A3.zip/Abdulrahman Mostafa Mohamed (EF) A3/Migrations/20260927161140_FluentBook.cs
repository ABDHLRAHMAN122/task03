﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace ConsoleApp23.Migrations
{
    public partial class FluentBook : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
