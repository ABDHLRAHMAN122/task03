﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp23.models
{
    /*
     Q1: Why did the property "Id" become a Primary Key
         without any explicit configuration?

         The Id property became a Primary Key because Entity Framework Core uses conventions 
         and automatically treats properties named Id or <EntityName>Id as Primary Keys.

     Q2: Why is "Country" nullable in the database
         while "Price" is not?

         Country is nullable because its C# property allows null (string?), while Price is non-nullable
         (decimal),EF Core creates Country as nullable and Price as NOT NULL.
    */
    public class Book
    {
        [Key]
        public int Id { get; set; } 
        [Required]
        [MaxLength(80)]
        public string Title {  get; set; } 
        [Required]
        public decimal Price { get; set; }
        
        public DateTime? PublisheDate { get; set; }    

    }
}
