﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using ConsoleApp23.models;
using Microsoft.EntityFrameworkCore.Migrations;

namespace ConsoleApp23.DbContexts
{
    internal class BookstoreDbContext : DbContext
    {

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer("Server=.;Database=BookstoreDB;Trusted_Connection=True;TrustServerCertificate=True;");
        }

       

        public DbSet<Book> Books { get; set; }
        public DbSet<Author> Authors { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Book>((D) =>
            {
                D.Property((D) => D.Title)
                    .IsRequired(true)
                    .HasMaxLength(150);

                D.Property((D) => D.Price)
                    .HasColumnType("Decimal(8,2)");

                D.Property((D) => D.PublisheDate)
                    .IsRequired(false);
            });


        }

    }
}
